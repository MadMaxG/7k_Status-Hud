$(document).ready(function() {
    window.addEventListener('message', function(event) {
        var data = event.data;

        if (data.id)
            $('#tid').text(data.id);

        if (event.data.action == 'updateStatus') {
            updateStatus(event.data.st);
        }

        if (data.setDisplay) {
            $('.container').css({ 'display': data.displayPause });
            $('.container-wrap').css({ 'display': data.displayDead });
        }

        if (data.health)
            $('#Hp').text(data.health);
        if (data.health > 20) {
            $('#hpreal').css('width', data.health + '%');
            /*$('.hp-box').css('animation', 'blinker-stop')*/
            $('.hp-box').css('background', 'rgba(184, 183, 183, 0.253)')
        } else if (data.health <= 20) {
            $('#hpreal').css('width', data.health + '%');
            /*$('.hp-box').css('animation', 'blinker 1s linear infinite')*/
            /*$('.hp-box').css('background', 'rgb(255, 0, 0, 0.5)')*/
            $('.hp-box').css('background', 'rgba(184, 183, 183, 0.253)')
        }

        if (data.armor == 0) {
            $('#Abox').hide();
        } else if (data.armor > 10) {
            $('#Abox').show();
            // $('#amreal').text(Math.floor(data.armor));
            $('#amreal').css('width', data.armor + '%');
            $('.am').css('animation', 'blinker-stop')
            $('.am').css('background', 'rgba(184, 183, 183, 0.253)')
        } else if (data.armor <= 10) {
            $('#Abox').show();
            // $('#amreal').text(Math.floor(data.armor));
            $('#amreal').css('width', data.armor + '%');
            $('.am').css('animation', 'blinker 1s linear infinite')
            $('.am').css('background', 'rgb(255, 0, 0, 0.5)')
        }

        if (data.stamina >= 100) {
            $("#stamina").show();
            $('#textstamina').text(Math.floor(data.stamina));
        } else if (data.stamina > 10) {
            $('#textstamina').text(Math.floor(data.stamina));
            $('#strreal').css('width', data.stamina + '%');
            $('.str').css('animation', 'blinker-stop')
            $('.str').css('background', 'rgba(184, 183, 183, 0.253)')
        } else if (data.stamina <= 10) {
            $('#textstamina').text(Math.floor(data.stamina));
            $('#strreal').css('width', data.stamina + '%');
            $('.str').css('animation', 'blinker 1s linear infinite')
            $('.str').css('background', 'rgb(255, 0, 0, 0.5)')
        }

        if (data.dive >= 100) {
            $('#dive').show();
            $('#textdrive').text(Math.floor(data.dive));
            $('#divreal').css('width', data.dive + '%');
            $('.div').css('background', 'rgba(184, 183, 183, 0.253)')
        } else if (data.dive > 32) {
            $('#dive').show();
            $('#textdrive').text(Math.floor(data.dive));
            $('#divreal').css('width', data.dive + '%');
            $('.div').css('background', 'rgba(184, 183, 183, 0.253)')
        } else if (data.dive <= 32) {
            $('#dive').show();
            if (data.dive >= 3)
                $('#textdrive').text(Math.floor(data.dive));
            else
                $('#textdrive').text(0);
            $('#boxDive').css('width', data.dive + '%');
            $('.div').css('background', 'rgb(255, 0, 0, 0.5)')
        }
    })
})

function updateStatus(status) {

    for (i = 0; i < status.length; i++) {

        if (status[i].name === 'hunger') {
            $('#thug').text(Math.round(status[i].percent));
            if (status[i].val > 100000) {
                $('#hugreal').css('width', status[i].percent + '%');
                $('.hug-altr').css('display', 'none');
            } else {
                $('#hugreal').css('width', status[i].percent + '%');
                $('.hug-altr').css('display', 'block');
            }
        }

        if (status[i].name === 'thirst') {
            $('#tthg').text(Math.round(status[i].percent));
            if (status[i].val > 100000) {
                $('#thgreal').css('width', status[i].percent + '%');
                $('.thg-altr').css('display', 'none');
            } else {
                $('#thgreal').css('width', status[i].percent + '%');
                $('.thg-altr').css('display', 'block');
            }
        }

    }
}