fx_version 'adamant'

game 'gta5'

description 'Status Bar'

version '0.1'

ui_page 'html/ui.html'

files {
    'html/img/*.png',
    'html/img/*.gif',
    "html/img/*.svg",
    'html/ui.html',
    'html/ui.css',
    'html/ui.js'
}

client_script {
    'client/main.lua',
}
